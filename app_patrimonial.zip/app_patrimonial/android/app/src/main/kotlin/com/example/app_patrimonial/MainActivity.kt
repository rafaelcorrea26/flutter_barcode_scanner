package com.example.app_patrimonial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
