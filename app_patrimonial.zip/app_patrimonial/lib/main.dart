import 'package:app_patrimonial/BarcodePage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(title: "Aplicativo de doação de sangue", home: BarcodePage()));
}
